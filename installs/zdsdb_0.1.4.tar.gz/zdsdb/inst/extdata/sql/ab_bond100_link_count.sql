SELECT srcAtomId, COUNT(DISTINCT dstAtomId) AS n_links
FROM AtomBonds
WHERE bondMatchId = 100
GROUP BY srcAtomId
ORDER BY n_links DESC, srcAtomId ASC;
