SELECT DISTINCT cpi.atomId, a.dstAtomId, cii.name AS 'institutionName', 
                cpi.address, cpi.city, cpi.state, cpi.zipcode,
                cpi.workPhone, cpi.email, cpi.specialty,
                cpi.latitude, cpi.longitude
FROM CachePhysicianInfo cpi
LEFT OUTER JOIN AtomBonds ab
  ON cpi.atomId = a.srcAtomId AND ab.bondMatchId = 100
LEFT OUTER JOIN CacheInstitutionInfo cii
  ON cii.atomId = ab.dstAtomId;
