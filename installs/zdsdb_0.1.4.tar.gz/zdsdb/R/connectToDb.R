#' Connect to remote Zephyr databases
#'
#' Syntactic sugar for connecting to a myriad of known databases.
#'
#' At this time, the only top-level key that's read from the config file is
#' "default." This will likely be generalized to accept more database "profiles"
#' in the future.
#'
#' @importFrom yaml yaml.load_file
#' @import RMySQL
#' @export
#' @param dbnick string. Nickname of database/schema. See
#' @param dbhost string. Database host URI.
#' @param dbschema string. Database schema name.
#' @param dbport integer. Database port number.
#' @param dbuser string. Database user name.
#' @param dbpass string. Database password.
#' @param use_user_dbconf_file bool. TRUE if you want to use a user-specific
#'   configuration file, given in "user_dbconf_file".
#' @param user_dbconf_file string. Path to user-specific configuration file.
#' @param default_dbconf_file string. Path to default configuration file.
#' @param ssh_gateway_uri string. SSH gateway URI.
#' @param ssh_gateway_user string. Username to authenticate into SSH gateway.
#' @param dbdict_file string. Path to database dictionary CSV.
#' @param verbose bool. Set to TRUE if you'd like additional verbosity.
#' @return RMySQL connection object.
#'
#' @section Nicknames: The use of nicknames is intended to facilitate connecting
#'   to our most common instances and schemas within those instances. The
#'   convention for these nicknames is
#'   "$\{client_abbreviation\}_$\{schema_name\}. Note that Astella and Novartis
#'   (which is non-working, at the moment) are still listed for historical
#'   purposes (though others, such as Sunesis, has been removed).
#'
#' \tabular{llll}{
#'   amg_zdb     \tab zdb_amg        \tab vpc-amgdb1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   demo_zdb    \tab zdbi_demo      \tab vpc-zdemo.ctqtxfordu4t.us-west-2.rds.amazonaws.com     \tab FALSE\cr
#'   gne_zdb     \tab zdbi_gne       \tab vpc-gnedb1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   gil_zdb     \tab zdb_gil        \tab vpc-gildb1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   nov_zdb     \tab zdb_nov        \tab di-novrds1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   ps1_zdb     \tab zdb_ps         \tab di-ps1rds1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   ps2_zdb     \tab zdb_ps         \tab di-ps2rds1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   ps3_zdb     \tab zdb_ps         \tab di-ps3rds1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   ps4_zdb     \tab zdb_ps         \tab di-ps4rds1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   roc_zdb     \tab zdb_roc        \tab di-rocrds1.ctqtxfordu4t.us-west-2.rds.amazonaws.com    \tab  TRUE\cr
#'   onyx_zdb    \tab zdb_onyx       \tab vpc-onyxdb1.ctqtxfordu4t.us-west-2.rds.amazonaws.com   \tab  TRUE\cr
#'   zcr_rl      \tab Record_Linkage \tab vpc-zcr.ctqtxfordu4t.us-west-2.rds.amazonaws.com       \tab FALSE\cr
#'   zcr_pubs    \tab pubs           \tab vpc-zcr.ctqtxfordu4t.us-west-2.rds.amazonaws.com       \tab FALSE\cr
#'   zcr_zdbi    \tab zdbi           \tab vpc-zcr.ctqtxfordu4t.us-west-2.rds.amazonaws.com       \tab FALSE
#' }
#'
#' @section Networking: As of writing (2015-02-27), the catch-all, default DI
#'   database user "apps" does not have SSH access (i.e. an account) on any VPC
#'   server. Thus, the 'ssh_gateway_user' argument is required. By default, this
#'   function will attempt to find the name of current system user, and attempt
#'   to use that username in connecting to the SSH gateway (rserv-ds by
#'   default).
#'
#' @section Database Authentication: This function allows users to either use
#'   the catch-all, default DI database user "apps", or use a personal config
#'   file. Currently, default behavior is to use the "apps" user. There are many
#'   reasons to do this. However, to increase security, this may change. See the
#'   dbconf.default.yaml file for an example of how this file is formatted.
#'
#' @section System Compatibility: This package is currently designed for
#'   *nix-based systems, e.g. on OSX and Ubuntu (the OS powering our VPC's).
#'   Specifically, this function will very likely fail on Windows systems, as it
#'   depends on several *nix commands to work.
#'
#' @examples
#' amg_zdb_con <- connectToDb("amg_zdb")
#' gne_zdb_con <- connectToDb("gne_zdb")
#'
#' \dontrun{
#' # If your system username is different from the username you want to use in
#' # connecting to the SSH gateway.
#' gil_zdb_con <- connectToDb("gil_zdb", ssh_gateway_user = "someuser")
#' }
#'
#' @author Victor Yee <vyee@@zephyrhealth.com>
#' @family database

connectToDb <- function(
  dbnick,
  dbhost = NULL, dbschema = NULL, dbport = 3306,
  dbuser = NULL, dbpass = NULL,
  use_user_dbconf_file = FALSE,
  user_dbconf_file = "~/.auth/dbconf.yaml",
  default_dbconf_file = system.file("extdata", "dbconf.default.yaml",
                                    package = "zdsdb"),
  ssh_gateway_uri = "rserv-ds.zephyr-intranet.com",
  ssh_gateway_user = system("whoami", intern = T),
  dbdict_file = system.file("extdata", "dbdict.csv",
                            package = "zdsdb"),
  verbose = TRUE) {

  ### Validate function arguments ----------------------------------------------

  ### Determine network location  ----------------------------------------------
  hostname <- system("hostname", intern = T)
  if (verbose) message("System Hostname: ", hostname)
  remote_location <- length(grep("zephyr-intranet.com", hostname))
  if (verbose) {
    if (remote_location) {
      message("Zephyr Health VPC: YES")
    } else {
      message("Zephyr Health VPC: NO")
    }
  }

  ### Get database credentials -------------------------------------------------

  # Use user-specific credentials if requested
  if (use_user_dbconf_file) {
    if (file.exists(user_dbconf_file)) {
      dbconf <- yaml.load_file(user_dbconf_file)
    } else {
      if (!remote_location) {
        warning(paste0(
          "use_user_dbconf_file parameter: TRUE \n",
          "Error loading user database configuration: ",
          user_dbconf_file, " does not exist."))
      }
      dbconf <- useDefaultDbConf(conf_file = default_dbconf_file,
                                 verbose   = verbose)
    }
  } else {
    # Use the default 'app' credentials (this is the default behavior)
    dbconf <- useDefaultDbConf(conf_file = default_dbconf_file,
                               verbose   = verbose)
  }

  ### Read database dictionary -------------------------------------------------
  # Example format:
  # "nick","schema","host"
  # "amg_zdb","zdb_amg","vpc-amgdb1.ctqtxfordu4t.us-west-2.rds.amazonaws.com"
  # "ast_zdb","zdb_ast","vpc-astdb1.ctqtxfordu4t.us-west-2.rds.amazonaws.com"
  # "demo_zdb","zdbi_demo","vpc-zdemo.ctqtxfordu4t.us-west-2.rds.amazonaws.com"
  # TODO: Generate these host name strings automatically (which would rely on
  #       these host name strings being consistently).
  dbdict <- read.csv(dbdict_file, as.is = T, header = T, stringsAsFactors = F)

  ### Get remote database host -------------------------------------------------
  if (!is.null(dbhost)) {
    if (verbose) {
      message("dbhost argument provided. This takes precedence over dbnick.")
    }
    remote_dbhost <- dbhost # If user specifies a host to use, then use that.
  } else {
    if (dbnick %in% dbdict$nick) {
      remote_dbhost <- dbdict[which(dbdict$nick == dbnick), "host"]
    } else {
      stop("dbnick '", dbnick, "' does not exist.")
    }
  }

  ### Get database schema ------------------------------------------------------
  if (!is.null(dbschema)) {
    if (verbose) {
      message("dbschema argument provided. This takes precedence over dbnick.")
    }
    dbschema <- dbschema # If user specifies a host to use, then use that.
  } else {
    dbschema <- dbdict[which(dbdict$nick == dbnick), "schema"]
  }

  ### Set local database host --------------------------------------------------
  if (remote_location) {
    final_dbhost <- remote_dbhost
  } else {
    final_dbhost <- "127.0.0.1"
    local_dbport <- findUnusedLocalPort(verbose = FALSE)
    if (verbose) {
      message("Unused Local Port Found: ", local_dbport)
    }

    ssh_login_uri      <- paste0(ssh_gateway_user, "@", ssh_gateway_uri)
    database_uri       <- paste0(local_dbport, ":", remote_dbhost, ":", dbport)
    ssh_tunnel_string  <- paste(ssh_login_uri, "-L", database_uri, "-N")
    ssh_tunnel_command <- paste("ssh -f", ssh_tunnel_string)

    if (verbose) {
      message("SSH Login URL: ", ssh_login_uri)
      message("Database URL: ", database_uri)
    }

    # TODO: Possible feedback on connection success / debug mode
    ssh_tunnel_command_status <- system(ssh_tunnel_command)

    # TODO: Error handling in case SSH tunneling fails
    if (verbose) {
      if (ssh_tunnel_command_status == "0") {
        message("SSH tunnel successfully established.")
      }
      else if (ssh_tunnel_command_status == "255") {
        message("Are you sure user '", ssh_gateway_user,
                "' can log into '", ssh_gateway_uri, "'?")
      }
    }
  }

  ### Validate configuration ---------------------------------------------------
  # TODO: Include some configuration validation

  ### Connect to MySQL database ------------------------------------------------
  con <- dbConnect(drv = DBI::dbDriver('MySQL'),
                   dbname = dbschema,
                   host = final_dbhost,
                   username = dbconf$default$user,
                   password = dbconf$default$pass,
                   port = ifelse(remote_location, dbport, local_dbport))
  return(con)
}
