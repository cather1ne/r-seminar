#' Table formatter for roxygen2 documentation
#'
#' The following function turns an R data frame into into the correct format. It
#' ignores column and row names, but should get you started.
#'
#' @param df data.frame. Data.frame you wish to format.
#' @param ... additional parameters to send to format().
#' @return string. The data.table formatted for roxygen2 documentation.
#'
#' @references
#' http://cran.r-project.org/web/packages/roxygen2/vignettes/formatting.html
#'
#' @examples
#' \dontrun{
#' cat(tabular(mtcars[1:5, 1:5]))
#'
#' # connectToDb
#' cat(tabular(read.csv("inst/extdata/dbdict.csv")))
#'
#' # prepDfForCdal
#' df[["value"]] <- t(data.frame(opts))
#' df <- data.frame(option = row.names(t(data.frame(opts))))
#' cat(tabular(df))
#' }


tabular <- function(df, ...) {
  stopifnot(is.data.frame(df))

  align <- function(x) if (is.numeric(x)) "r" else "l"
  col_align <- vapply(df, align, character(1))

  cols <- lapply(df, format, ...)
  contents <- do.call("paste",
                      c(cols, list(sep = " \\tab ", collapse = "\\cr\n  ")))

  paste("\\tabular{", paste(col_align, collapse = ""), "}{\n  ",
        contents, "\n}\n", sep = "")
}
