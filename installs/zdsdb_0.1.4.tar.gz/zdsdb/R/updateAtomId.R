#' Retrieve the most up-to-date atomId for a given HCP or Inst atomId
#'
#' This function retrieves the most up-to-date atomId for any given atomId. It
#' can handle either HCP or Institution atomIds. For HCP atomIds, the
#' IsotopeAtomChangeLog table (in a given zdb schema) is used. For Institution
#' atomIds, the didb.InstitutionMatchLog is used. Because the
#' InstitutionMatchLog was not intended to track Institution atomId changes,
#' Aaron Chaiclin has informed me that this query may not always be accurate.
#'
#' @export
#' @param con RMySQL connection object. Assumes that the connection is to the
#'   zdb schema.
#' @param atom_id integer. The atomId you want to query. If there is no newer
#'   atomId, the same atomId will returned. WARNING: There is no check against
#'   nonexistent atomIds. So an atomId of, for example, "12345" will return
#'   "12345", even if the atomId "12345" doesn't exist.
#' @param atom_type Either exactly "hcp" or "inst".
#' @param verbose logical. If TRUE, more messages will be printed.
#' @return integer. The updated atomId.
#'
#' @note Forked from updateHcpAtomIds and updateInstAtomIds
#'
#' @examples
#' # HCP atomIds
#' con <- connectToDb("amg_zdb")
#' updateAtomId(con, 3795853, atom_type = "hcp") # 3774533 (as of 2015-03-02)
#' updateAtomId(con, 3795737, atom_type = "hcp", verbose = TRUE)
#'                                               # 3795737 (as of 2015-03-02)
#'
#' # Institution atomId
#' updateAtomId(con, 4369361, atom_type = "inst", verbose = TRUE)
#'
#' \dontrun{
#' updateAtomId(con, 4369361) # ERROR: Please select exactly one atom_type.
#' }
#'
#' @author Victor Yee <vyee@@zephyrhealth.com>
#' @family database

updateAtomId <- function(con, atom_id,
                         atom_type = c("hcp", "inst"),
                         verbose = F) {

  # Ensure that the atomId column is integer-typed
  if (!is.numeric(atom_id)) {
    warning(atom_id, " is non-numeric.")
  }
  if (!is.integer(atom_id)) {
    atom_id_original <- atom_id
    atom_id <- as.integer(atom_id)
    if (verbose) {
      message("Converting ", atom_id_original, " to integer: ", atom_id)
    }
  }

  # Ensure that a correct atom_type is entered
  atom_type <- match.arg(atom_type, several.ok = T)
  if (length(atom_type) != 1) {
    stop("Please select exactly one atom_type.")
  }
  if (!atom_type %in% c("hcp", "inst")) {
    stop("Unknown atom_type: ", atom_type)
  } else {
    if (verbose) {
      message("Selected atom_type: ", atom_type)
    }
  }
  if (atom_type == "inst") {
    warning("Institution atomId updater may be inaccurate or unreliable!")
  }

  # Ensure that the connection session is UTF-8-encoded
  dbSendQuery(con, "SET NAMES utf8;")

  # Attempt to determine atom_type if not given (DOES NOT WORK)
  # if (length(atom_type) > 1) {
  #   if (verbose) {
  #     message(paste("More than one atom type was specified.",
  #                   "Attempting to determine correct type."))
  #   }
  #   query_string <-
  #     paste("SELECT Elements.name
  #             FROM Isotopes
  #             JOIN Elements USING(elementId)
  #             WHERE atomId =", atom_id_int,
  #            "LIMIT 1;")
  #   rs           <- dbSendQuery(con, query_string)
  #   atom_type    <- fetch(rs, n = -1)[["name"]]
  #   dbClearResult(dbListResults(con)[[1]])
  #   dbClearResult(rs)
  # }

  constructQuery <- function(atom_id, atom_type) {
    if (atom_type == "hcp") {
      query_string <-
        paste("SELECT DISTINCT oldAtomId, newAtomId
               FROM IsotopeAtomChangeLog
               WHERE oldAtomId =", atom_id, ";")
    } else if (atom_type == "inst") {
      query_string <-
        paste("SELECT DISTINCT atomId AS 'newAtomId',
                               matchAtomId AS 'oldAtomId'
               FROM didb.InstitutionMatchLog
               WHERE matchAtomId =", atom_id, ";")
    } else {
      stop("Unknown atom_type: ", atom_type)
    }
    return(query_string)
  }

  queryRecursive <- function(con, atom_id, atom_type) {
    rs           <- dbSendQuery(con, constructQuery(atom_id, atom_type))
    results      <- fetch(rs, n = -1)
    dbClearResult(dbListResults(con)[[1]])
    dbClearResult(rs)

    # Search recursively for any newer atomIds
    if (nrow(results) == 0) {
      return(atom_id)
    } else {
      atom_changes <- results
      while(nrow(results) > 0) {
        new_atom_id  <- results[["newAtomId"]]
        query_string <- constructQuery(new_atom_id, atom_type)
        rs           <- dbSendQuery(con, query_string)
        results      <- fetch(rs, n = -1)
        dbClearResult(dbListResults(con)[[1]])
        dbClearResult(rs)
        if(nrow(results) > 0) {
          atom_changes <- results
        }
      }
      return(atom_changes[["newAtomId"]])
    }
  }

  return(queryRecursive(con, atom_id, atom_type))
}
