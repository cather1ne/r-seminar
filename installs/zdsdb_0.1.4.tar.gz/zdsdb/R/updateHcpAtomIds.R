#' Modify-in-place HCP atomIds with current platform HCP atomIds
#'
#' This function, along with its sibling updateInstAtomIds, was forked (by
#' Victor Yee) from code originally written by Hope Johnson (who left Zephyr in
#' November 2014). It was intended to update all atomIds in a given table with
#' the most up-to-date atomIds available.
#'
#' This function has been deprecated in favor of updateAtomId(), which is less
#' divisible and thus more flexible. I have included this function for backwards
#' compatibility and historical purposes.
#'
#' @export
#'
#' @param con RMySQL connection object. Assumes that the connection is to the
#'   zdb schema.
#' @param df data.frame. The data.frame (or data.table) containing the atomIds
#'   you wish to update.
#' @param atom_id_col string. The name of the atomId column. By default, this is
#'   "atomId", which
#'
#' @note Originally stored at Box Sync/Customer Success Data
#'   Science/Projects/AtomId Updates
#'
#' @author Victor Yee <vyee@@zephyrhealth.com>
#' @family database-tools
#' @seealso \code{\link{updateInstAtomIds}}

updateHcpAtomIds <- function(con, df, atom_id_col = "atomId") {
  .Deprecated("updateAtomId")

  # Ensure that the atomId column is integer-typed
  df[[atom_id_col]] <- as.integer(as.character(df[[atom_id_col]]))

  # Ensure that the connection session is UTF-8-encoded
  dbSendQuery(con, "SET NAMES utf8;")

  listParser <- function(x) {
    collapsed <- paste(x, ",", sep = "", collapse = "")
    collapsed <- substr(collapsed, 1, nchar(collapsed) - 1)
    return(collapsed)
  }

  src_atoms    <- listParser(df[[atom_id_col]])
  query_string <-
    paste("SELECT DISTINCT oldAtomId, newAtomId
           FROM IsotopeAtomChangeLog
           WHERE oldAtomId IN (", src_atoms, ");",
          sep = "", collapse = "")
  rs           <- dbSendQuery(con, query_string)
  results      <- fetch(rs, n = -1)
  dbClearResult(dbListResults(con)[[1]])
  dbClearResult(rs)

  atom_changes <- results

  while(nrow(results) > 0) {
    src_atoms    <- listParser(results$newAtomId)
    query_string <-
      paste("SELECT DISTINCT oldAtomId, newAtomId
             FROM IsotopeAtomChangeLog
             WHERE oldAtomId IN (", src_atoms, ");",
            sep = "", collapse = "")
    query_string <- iconv(query_string, "UTF-8", "latin1")
    rs           <- dbSendQuery(con, query_string)
    results      <- fetch(rs, n = -1)
    dbClearResult(dbListResults(con)[[1]])
    dbClearResult(rs)
    if(nrow(results) > 0) {
      changedInds <- match(atom_changes$newAtomId, results$oldAtomId)
      changedInds <- changedInds[!is.na(changedInds)]
      atom_changes$newAtomId <- replace(atom_changes$newAtomId,
                                        which(atom_changes$newAtomId %in% results$oldAtomId),
                                        results$newAtomId[changedInds])
    }
  }

  # Update original data with updated atomIds ----------------------------------
  changes <- match(df[[atom_id_col]], atom_changes$oldAtomId)
  changes <- changes[!is.na(changes)]
  df[[atom_id_col]] <-
    replace(df[[atom_id_col]],
            which(df[[atom_id_col]] %in% atom_changes$oldAtomId),
            atom_changes$newAtomId[changes])
  return(df)
}


