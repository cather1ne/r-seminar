findUnusedLocalPort <- function(initial_port = 3307,
                                max_number_of_attempts = 100,
                                verbose = TRUE) {
  success <- FALSE
  number_of_attempts <- 0
  while (!success && number_of_attempts < max_number_of_attempts) {
    port_to_test <- initial_port + number_of_attempts
    stdout <- suppressWarnings(system(paste0("lsof -i :", port_to_test),
                                      intern = TRUE))
    success <- length(stdout) == 0
    number_of_attempts <- number_of_attempts + 1
    if (verbose && !success) {
      cat(paste("Port", port_to_test, "in use."), "\n")
    }
  }
  unused_port <- port_to_test
  return(unused_port)
}