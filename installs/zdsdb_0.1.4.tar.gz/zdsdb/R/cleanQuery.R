#' Send query, retrieve results and then clear result set.
#'
#' This is a legacy database function that will be deprecated in the next
#' version of \code{zdsdb}. Use \link[DBI]{dbGetQuery} instead.
#'
#' @importFrom DBI dbGetQuery
#' @export
#'
#' @inheritParams DBI::dbGetQuery
#'
cleanQuery <- function(conn, statement, ...) {
  message("  cleanQuery() will be deprecated in the next version of zdsdb.\n",
          "  Use DBI::dbGetQuery instead.")
  DBI::dbGetQuery(conn = conn, statement = statement, ...)
}
