useDefaultDbConf <- function(conf_file, verbose = TRUE) {
  if (file.exists(conf_file)) {
    dbconf <- yaml.load_file(conf_file)
  } else {
    # if default database config file isn't found, then attempt these hard-coded credentials...
    dbconf$app$user <- "app"
    dbconf$app$pass <- "twenty1guns!"
  }
  if (verbose) {
    message(paste0("Default database user: '", dbconf$default$user, "' loaded!"))
  }
  return(dbconf)
}
