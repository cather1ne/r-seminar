.onAttach <- function(libname, pkgname) {
  pkg_version <- utils::packageVersion("zdsdb")
  pkg_date    <- utils::packageDescription("zdsdb", fields = "Date")
  packageStartupMessage(paste0(
    "Welcome to Zephyr Health Data Science!\n",
    "zdsdb ", pkg_version, " (", pkg_date, ")",
    "  For help type: help(\"zdsdb\")"))
}

#' Syntactic sugar for interacting with Zephyr databases. All reusable R
#' functions for connecting to, querying, and interacting with Zephyr databases
#' go here.
#'
#' @docType package
#' @name zdsdb
NULL
