#' Cleans up a SQL file to be read into R
#'
#' This function removes leading whitespace and commented lines, as well as
#' replacing tabs with a single space and collapsing all lines in the SQL file
#' into one string. Using this function to read and clean up a SQL file is not
#' particularly necessary but is nice to have.
#'
#' @export parseSqlFile
#' @export QueryParser_FUNC
#'
#' @param sql_filename string. Path to the SQL file.
#' @return string. The SQL query in one line.
#'
#' @aliases parseSqlFile QueryParser_FUNC
#' @author Jiejing Zhao <jiejing@@zephyrhealth>
#' @family database

parseSqlFile <- QueryParser_FUNC <- function(sql_filename) {
  sql <- readLines(con = file(sql_filename), encoding = "UTF-8")
  sql <- gsub("^ *", "", sql)
  sql <- sql[which(grepl("^#", sql) == FALSE)]
  sql <- gsub("\t", " ", sql)
  sql <- paste(sql, collapse = " ")
  return(sql)
}
