#' data.frame CDAL-DB pre-flight checks
#'
#' Experimental function for checking & preparing a data.frame for CDAL-DB
#' import. NOT FOR PRODUCTION USE (YET)!!!
#'
#' @importFrom DBI dbQuoteString dbListTables dbGetQuery
#' @import RMySQL
#' @export
#'
#' @param conn A \code{DBIConnection} object, as produced by
#'   \code{DBI::dbConnect}.
#' @param df data.frame. Dataset to check.
#' @param opts list. Settings.
#'
#' @section Settings:
#'
#' \tabular{ll}{
#' convert_factor_to_character    \tab TRUE              \cr
#' quote_all_strings              \tab TRUE              \cr
#' convert_all_columns_to_strings \tab TRUE              \cr
#' replace_na_with_null           \tab TRUE              \cr
#' check_atoms_against_cache      \tab TRUE              \cr
#' atom_id_colname                \tab atomId            \cr
#' atom_cache_table               \tab CachePhysicianInfo\cr
#' uncached_atoms_action          \tab omit
#' }
#'
#' @examples
#' library(RMySQL)
#' conn_ds1 <- DBI::dbConnect(
#'   drv      = RMySQL::MySQL(),
#'   dbname   = "zdb_gil",
#'   host     = "10.1.0.151",
#'   username = "apps",
#'   password = "twenty1guns!")
#' test_df <- data.frame(atomId = sample(c(1, 538, 711, 932, 979), size = 10, replace = TRUE),
#'                       pubId  = sample(letters[1:3], size = 10, replace = TRUE),
#'                       score  = rexp(10, rate = 1/10))
#' test_df <- test_df[order(test_df$atomId, test_df$pubId, test_df$score), ]
#' prepDfForCdal(conn = conn_ds1,
#'               df = test_df)
#'
prepDfForCdal <- function(
  conn, df, opts = list(
    convert_factor_to_character    = TRUE,
    quote_all_strings              = TRUE,
    convert_all_columns_to_strings = TRUE,
    replace_na_with_null           = TRUE,
    check_atoms_against_cache      = TRUE,
    atom_id_colname                = "atomId",
    atom_cache_table               = "CachePhysicianInfo",
    uncached_atoms_action          = "omit" # also allow "pass" and "fail"
  )) {

  # df <- DBI::rownamesToColumn(df, row.names)

  if (opts$convert_factor_to_character) {
    is_factor <- vapply(df, is.factor, logical(1))
    df[is_factor] <- lapply(df[is_factor], as.character)
  }

  if (opts$quote_all_strings) {
    is_char <- vapply(df, is.character, logical(1))
    df[is_char] <- lapply(df[is_char], function(x) {
      enc2utf8(DBI::dbQuoteString(conn, x))
    })
  }

  if (opts$convert_all_columns_to_strings) {
    df[] <- lapply(df, as.character)
  }

  if (opts$replace_na_with_null) {
    df[is.na(df)] <- "NULL"
  }

  if (opts$check_atoms_against_cache) {
    if (!any(opts$atom_id_colname == names(df))) {
      stop("atom_id_colname of ", opts$atom_id_colname,
           " not found in ", deparse(substitute(df)), ".")
    }
    if (!any(opts$atom_cache_table == DBI::dbListTables(conn = conn))) {
      stop("atom_cache_table of ", opts$atom_cache_table,
           " not found in database connection.")
    }
    df_atoms     <- unique(df[[opts$atom_id_colname]])
    cached_atoms_query <-
      paste0("SELECT atomId", "\n",
             "FROM ", opts$atom_cache_table, " AS CacheTable", "\n",
             "WHERE CacheTable.atomId IN ",
             "(", paste(df_atoms, collapse = ", "), ");")
    cached_atoms <- DBI::dbGetQuery(conn = conn,
                                    statement = cached_atoms_query)$atomId
    atoms_missing_from_cache <- setdiff(df_atoms, cached_atoms)
    atoms_missing_from_cache_message <-
      paste("data contains atomId's missing from cache:",
            paste(atoms_missing_from_cache, collapse = ", "))
    if (opts$uncached_atoms_action == "omit") {
      warning(atoms_missing_from_cache_message)
      df <- df[!(df[[opts$atom_id_colname]] %in% atoms_missing_from_cache), ]
    } else if (opts$uncached_atoms_action == "fail") {
      stop(atoms_missing_from_cache_message)
    } else if (opts$uncached_atoms_action == "pass") {
      warning(atoms_missing_from_cache_message)
      df <- df
    } else {
      stop("uncached_atoms_action of '", opts$uncached_atoms_action, "not recognized.", "\n",
           "I'm only accepting 'omit', 'fail', or 'pass' right now.")
    }
  }

  return(df)
}
