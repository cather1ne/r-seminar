library(zdsdb)
library(RMySQL)
context("Database Tools")

# Default credentials & database dictionary can be found. ----------------------
test_that("Default credentials & database dictionary can be found.", {

  expect_that(system.file("extdata", "dbconf.default.yaml",
                          package = "zdsdb") != "",           is_true())
  expect_that(system.file("extdata", "dbdict.csv",
                          package = "zdsdb") != "",           is_true())

})

# Records can be retrieved from the Particles table. ---------------------------
test_that("Records can be retrieved from the Particles table.", {

  testConnection <- function(dbnick,
                             ssh_gateway_uri = "rserv-ds.zephyr-intranet.com",
                             verbose = FALSE, ...) {
    conn <- connectToDb(dbnick,
                        ssh_gateway_uri = ssh_gateway_uri,
                        verbose = verbose, ...)
    statement <- switch(dbnick,
      zcr_rl   = "SELECT id FROM rl LIMIT 5;",
      zcr_pubs = "SELECT * FROM Identifiers LIMIT 5;",
      "SELECT * FROM Particles LIMIT 5;"
    )
    results <- DBI::dbGetQuery(conn = conn, statement = statement)
    if (verbose) print(results)
    if (length(results) > 0) {
      return(list(dbnick = dbnick,
                  result = TRUE))
    } else {
      return(list(dbnick = dbnick,
                  result = FALSE))
    }
  }

  expect_true(testConnection("amg_zdb",     verbose = F)$result)
  expect_true(testConnection("demo_zdb",    verbose = F)$result)
  expect_true(testConnection("gne_zdb",     verbose = F)$result)
  expect_true(testConnection("gil_zdb",     verbose = F)$result)
  expect_true(testConnection("nov_zdb",     verbose = F)$result)
  expect_true(testConnection("ps1_zdb",     verbose = F)$result)
  expect_true(testConnection("ps2_zdb",     verbose = F)$result)
  expect_true(testConnection("ps3_zdb",     verbose = F)$result)
  expect_true(testConnection("ps4_zdb",     verbose = F)$result)
  expect_true(testConnection("roc_zdb",     verbose = F)$result)
  expect_true(testConnection("onyx_zdb",    verbose = F)$result)
  expect_true(testConnection("zcr_rl",      verbose = F)$result)
  expect_true(testConnection("zcr_pubs",    verbose = F)$result)
  expect_true(testConnection("zcr_zdbi",    verbose = F)$result)

  # Clear all remaining uncleared resultsets (uncleared resultsets prevent
  #   connections being closed)
  lapply(unlist(lapply(
    dbListConnections(dbDriver("MySQL")),
         dbListResults)),
    dbClearResult)

  # Close database connections set up during testing
  lapply(dbListConnections(dbDriver("MySQL")), dbDisconnect)

})

test_that("The atomId updater functions work.", {

  # The following may need to be updated with the actual data.
  conn_amg <- connectToDb("amg_zdb")
  expect_true( updateAtomId(conn_amg, 3795853, atom_type = "hcp") == 3774533)
  expect_true( updateAtomId(conn_amg, 3795737, atom_type = "hcp", verbose = T) == 3795737)
  expect_error(updateAtomId(conn_amg, 4369361))

  # Close database connections set up during testing
  lapply(dbListConnections(dbDriver("MySQL")), dbDisconnect)

})

test_that("Remaining aliased legacy database functions should work.", {

  conn_amg <- connectToDb("amg_zdb")
  test_sql_file <- system.file("extdata", "sql/ab_bond100_link_count.sql",
                               package = "zdsdb")
  test_sql_string <- paste("SELECT srcAtomId, COUNT(DISTINCT dstAtomId) AS n_links",
                           "FROM AtomBonds WHERE bondMatchId = 100",
                           "GROUP BY srcAtomId ORDER BY n_links DESC, srcAtomId ASC;")

  # parseSqlFile()/QueryParser_FUNC()
  expect_true(parseSqlFile(test_sql_file) == test_sql_string)
  expect_true(QueryParser_FUNC(test_sql_file) == test_sql_string)

})
