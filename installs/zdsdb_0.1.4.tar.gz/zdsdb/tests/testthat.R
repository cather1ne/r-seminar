library(testthat)
library(zdsdb)

test_check("zdsdb")
